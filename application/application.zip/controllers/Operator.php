<?php

use FontLib\Table\Type\post;

defined('BASEPATH') or exit('No direct script access allowed');

class Operator extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        date_default_timezone_set('Asia/Jakarta');
        if ($this->session->userdata('user_level') != "operator") {
            $this->session->sess_destroy();
            redirect(base_url("login"));
        }
        $this->load->model('M_admin', 'm_admin');
    }
    public function index()
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $id_user = $this->session->userdata("user_id");
        $data['a'] = $this->db->query("SELECT * FROM arsip where arsip_kategori='2' AND arsip_user = $id_user")->num_rows();
        $data['b'] = $this->db->query("SELECT * FROM arsip where arsip_kategori='3' AND arsip_user = $id_user")->num_rows();
        $data['c'] = $this->db->query("SELECT * FROM arsip where arsip_kategori='4' AND arsip_user = $id_user")->num_rows();
        $data['d'] = $this->db->query("SELECT * FROM arsip where arsip_kategori='5' AND arsip_user = $id_user")->num_rows();
        $data['e'] = $this->db->query("SELECT * FROM arsip where arsip_kategori='6' AND arsip_user = $id_user")->num_rows();
        $data['f'] = $this->db->query("SELECT * FROM arsip where arsip_kategori='7' AND arsip_user = $id_user")->num_rows();
        $data['g'] = $this->db->query("SELECT * FROM arsip where arsip_kategori='8' AND arsip_user = $id_user")->num_rows();
        $data['h'] = $this->db->query("SELECT * FROM arsip where arsip_kategori='9' AND arsip_user = $id_user")->num_rows();
        $data['i'] = $this->db->query("SELECT * FROM arsip where arsip_kategori='10' AND arsip_user = $id_user")->num_rows();
        $data['aa'] = $this->db->query("SELECT * FROM arsip where arsip_kategori='11' AND arsip_user = $id_user")->num_rows();
        $data['bb'] = $this->db->query("SELECT * FROM arsip where arsip_kategori='12' AND arsip_user = $id_user")->num_rows();
        $data['cc'] = $this->db->query("SELECT * FROM arsip where arsip_kategori='13' AND arsip_user = $id_user")->num_rows();

        $this->template_op->load('template_op', 'operator/v_operator', $data);
    }
    public function standar1($sub_arsip_id)
    {

        $id_user = $this->session->userdata("user_id");
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        if ($this->session->userdata('user_akses') == '2') {
            $data['title1'] = "Standar 1";
            $data['title2'] = "Visi, Misi, Tujuan dan Strategi";
            $data['title3'] = $this->db->query('SELECT * FROM sub_arsip WHERE sub_arsip_id =' . $sub_arsip_id)->row();
            $data['ts'] = $this->db->query('SELECT * FROM sub_arsip WHERE sub_arsip_id =' . $sub_arsip_id)->row();
            $ts = $this->input->post('pilihts', TRUE);
            if ($ts == "") {
                $data['masuk'] = $this->m_admin->standar1_op($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar1', $data);
            } elseif ($ts == "1") {
                $data['masuk'] = $this->m_admin->standar1_opts($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar1', $data);
            } elseif ($ts == "2") {
                $data['masuk'] = $this->m_admin->standar1_opts1($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar1', $data);
            } elseif ($ts == "3") {
                $data['masuk'] = $this->m_admin->standar1_opts2($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar1', $data);
            }
        } else {
            echo "<script>
            alert('Anda Tidak Mendapatkan Akses Ini');
            window.location='" . site_url('operator') . "'
        </script>";
        }
    }
    public function standar2($sub_arsip_id)
    {
        $id_user = $this->session->userdata("user_id");
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        if ($this->session->userdata('user_akses') == '3') {
            $data['title1'] = "Standar 2";
            $data['title2'] = "Tata Pamong, Tata Kelola dan Kerjasama";
            $id_user = $this->session->userdata("user_id");
            $data['title3'] = $this->db->query('SELECT * FROM sub_arsip WHERE sub_arsip_id =' . $sub_arsip_id)->row();
            $data['ts'] = $this->db->query('SELECT * FROM sub_arsip WHERE sub_arsip_id =' . $sub_arsip_id)->row();
            $ts = $this->input->post('pilihts', TRUE);
            if ($ts == "") {
                $data['masuk'] = $this->m_admin->standar2_op($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar2', $data);
            } elseif ($ts == "1") {
                $data['masuk'] = $this->m_admin->standar2_opts($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar2', $data);
            } elseif ($ts == "2") {
                $data['masuk'] = $this->m_admin->standar2_opts1($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar2', $data);
            } elseif ($ts == "3") {
                $data['masuk'] = $this->m_admin->standar2_opts2($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar2', $data);
            }
        } else {
            echo "<script>
            alert('Anda Tidak Mendapatkan Akses Ini');
            window.location='" . site_url('operator') . "'
        </script>";
        }
    }
    public function standar3($sub_arsip_id)
    {
        $id_user = $this->session->userdata("user_id");
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        if ($this->session->userdata('user_akses') == '4') {
            $data['title1'] = "Standar 3";
            $data['title2'] = "Mahasiswa";
            $id_user = $this->session->userdata("user_id");
            $data['title3'] = $this->db->query('SELECT * FROM sub_arsip WHERE sub_arsip_id =' . $sub_arsip_id)->row();
            $data['ts'] = $this->db->query('SELECT * FROM sub_arsip WHERE sub_arsip_id =' . $sub_arsip_id)->row();
            $ts = $this->input->post('pilihts', TRUE);
            if ($ts == "") {
                $data['masuk'] = $this->m_admin->standar3_op($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar3', $data);
            } elseif ($ts == "1") {
                $data['masuk'] = $this->m_admin->standar3_opts($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar3', $data);
            } elseif ($ts == "2") {
                $data['masuk'] = $this->m_admin->standar3_opts1($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar3', $data);
            } elseif ($ts == "3") {
                $data['masuk'] = $this->m_admin->standar3_opts2($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar3', $data);
            }
        } else {
            echo "<script>
            alert('Anda Tidak Mendapatkan Akses Ini');
            window.location='" . site_url('operator') . "'
        </script>";
        }
    }

    public function standar4($sub_arsip_id)
    {
        $id_user = $this->session->userdata("user_id");
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        if ($this->session->userdata('user_akses') == '3') {
            $data['title1'] = "Standar 4";
            $data['title2'] = "Sumber Daya Manusia";
            $id_user = $this->session->userdata("user_id");
            $data['title3'] = $this->db->query('SELECT * FROM sub_arsip WHERE sub_arsip_id =' . $sub_arsip_id)->row();
            $data['ts'] = $this->db->query('SELECT * FROM sub_arsip WHERE sub_arsip_id =' . $sub_arsip_id)->row();
            $ts = $this->input->post('pilihts', TRUE);
            if ($ts == "") {
                $data['masuk'] = $this->m_admin->standar4_op($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar4', $data);
            } elseif ($ts == "1") {
                $data['masuk'] = $this->m_admin->standar4_opts($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar4', $data);
            } elseif ($ts == "2") {
                $data['masuk'] = $this->m_admin->standar4_opts1($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar4', $data);
            } elseif ($ts == "3") {
                $data['masuk'] = $this->m_admin->standar4_opts2($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar4', $data);
            }
        } else {
            echo "<script>
            alert('Anda Tidak Mendapatkan Akses Ini');
            window.location='" . site_url('operator') . "'
        </script>";
        }
    }
    public function standar5($sub_arsip_id)
    {
        $id_user = $this->session->userdata("user_id");
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        if ($this->session->userdata('user_akses') == '5') {
            $data['title1'] = "Standar 5";
            $data['title2'] = "Keuangan, Sarana dan Prasarana";
            $id_user = $this->session->userdata("user_id");
            $data['title3'] = $this->db->query('SELECT * FROM sub_arsip WHERE sub_arsip_id =' . $sub_arsip_id)->row();
            $data['ts'] = $this->db->query('SELECT * FROM sub_arsip WHERE sub_arsip_id =' . $sub_arsip_id)->row();
            $ts = $this->input->post('pilihts', TRUE);
            if ($ts == "") {
                $data['masuk'] = $this->m_admin->standar5_op($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar5', $data);
            } elseif ($ts == "1") {
                $data['masuk'] = $this->m_admin->standar5_opts($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar5', $data);
            } elseif ($ts == "2") {
                $data['masuk'] = $this->m_admin->standar5_opts1($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar5', $data);
            } elseif ($ts == "3") {
                $data['masuk'] = $this->m_admin->standar5_opts2($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar5', $data);
            }
        } else {
            echo "<script>
            alert('Anda Tidak Mendapatkan Akses Ini');
            window.location='" . site_url('operator') . "'
        </script>";
        }
    }
    public function standar6($sub_arsip_id)
    {
        $id_user = $this->session->userdata("user_id");
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        if ($this->session->userdata('user_akses') == '6') {
            $data['title1'] = "Standar 6";
            $data['title2'] = "Pendidikan";
            $id_user = $this->session->userdata("user_id");
            $data['title3'] = $this->db->query('SELECT * FROM sub_arsip WHERE sub_arsip_id =' . $sub_arsip_id)->row();
            $data['ts'] = $this->db->query('SELECT * FROM sub_arsip WHERE sub_arsip_id =' . $sub_arsip_id)->row();
            $ts = $this->input->post('pilihts', TRUE);
            if ($ts == "") {
                $data['masuk'] = $this->m_admin->standar6_op($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar6', $data);
            } elseif ($ts == "1") {
                $data['masuk'] = $this->m_admin->standar6_opts($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar6', $data);
            } elseif ($ts == "2") {
                $data['masuk'] = $this->m_admin->standar6_opts1($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar6', $data);
            } elseif ($ts == "3") {
                $data['masuk'] = $this->m_admin->standar6_opts2($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar6', $data);
            }
        } else {
            echo "<script>
            alert('Anda Tidak Mendapatkan Akses Ini');
            window.location='" . site_url('operator') . "'
        </script>";
        }
    }
    public function standar7($sub_arsip_id)
    {
        $id_user = $this->session->userdata("user_id");
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        if ($this->session->userdata('user_akses') == '7') {
            $data['title1'] = "Standar 7";
            $data['title2'] = "Penelitian";
            $id_user = $this->session->userdata("user_id");
            $data['title3'] = $this->db->query('SELECT * FROM sub_arsip WHERE sub_arsip_id =' . $sub_arsip_id)->row();
            $data['ts'] = $this->db->query('SELECT * FROM sub_arsip WHERE sub_arsip_id =' . $sub_arsip_id)->row();
            $ts = $this->input->post('pilihts', TRUE);
            if ($ts == "") {
                $data['masuk'] = $this->m_admin->standar7_op($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar7', $data);
            } elseif ($ts == "1") {
                $data['masuk'] = $this->m_admin->standar7_opts($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar7', $data);
            } elseif ($ts == "2") {
                $data['masuk'] = $this->m_admin->standar7_opts1($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar7', $data);
            } elseif ($ts == "3") {
                $data['masuk'] = $this->m_admin->standar7_opts2($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar7', $data);
            }
        } else {
            echo "<script>
            alert('Anda Tidak Mendapatkan Akses Ini');
            window.location='" . site_url('operator') . "'
        </script>";
        }
    }
    public function standar8($sub_arsip_id)
    {
        $id_user = $this->session->userdata("user_id");
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        if ($this->session->userdata('user_akses') == '7') {
            $data['title1'] = "Standar 8";
            $data['title2'] = "Pengabdian Kepada Masyarakat";
            $id_user = $this->session->userdata("user_id");
            $data['title3'] = $this->db->query('SELECT * FROM sub_arsip WHERE sub_arsip_id =' . $sub_arsip_id)->row();
            $data['ts'] = $this->db->query('SELECT * FROM sub_arsip WHERE sub_arsip_id =' . $sub_arsip_id)->row();
            $ts = $this->input->post('pilihts', TRUE);
            if ($ts == "") {
                $data['masuk'] = $this->m_admin->standar8_op($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar8', $data);
            } elseif ($ts == "1") {
                $data['masuk'] = $this->m_admin->standar8_opts($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar8', $data);
            } elseif ($ts == "2") {
                $data['masuk'] = $this->m_admin->standar8_opts1($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar8', $data);
            } elseif ($ts == "3") {
                $data['masuk'] = $this->m_admin->standar8_opts2($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar8', $data);
            }
        } else {
            echo "<script>
            alert('Anda Tidak Mendapatkan Akses Ini');
            window.location='" . site_url('operator') . "'
        </script>";
        }
    }
    public function standar9($sub_arsip_id)
    {
        $id_user = $this->session->userdata("user_id");
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        if ($this->session->userdata('user_akses') == '1') {
            $data['title1'] = "Standar 9";
            $data['title2'] = "Luaran dan Capaian Tridharma";
            $id_user = $this->session->userdata("user_id");
            $data['title3'] = $this->db->query('SELECT * FROM sub_arsip WHERE sub_arsip_id =' . $sub_arsip_id)->row();
            $data['ts'] = $this->db->query('SELECT * FROM sub_arsip WHERE sub_arsip_id =' . $sub_arsip_id)->row();
            $ts = $this->input->post('pilihts', TRUE);
            if ($ts == "") {
                $data['masuk'] = $this->m_admin->standar9_op($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar9', $data);
            } elseif ($ts == "1") {
                $data['masuk'] = $this->m_admin->standar9_opts($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar9', $data);
            } elseif ($ts == "2") {
                $data['masuk'] = $this->m_admin->standar9_opts1($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar9', $data);
            } elseif ($ts == "3") {
                $data['masuk'] = $this->m_admin->standar9_opts2($id_user, $sub_arsip_id);
                $this->template_op->load('template_op', 'operator/standar9', $data);
            }
        } else {
            echo "<script>
            alert('Anda Tidak Mendapatkan Akses Ini');
            window.location='" . site_url('operator') . "'
        </script>";
        }
    }

    //TAMBAH VIEW
    public function tambah()
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['standar'] = $this->m_admin->get_standar();
        $this->template_op->load('template_op', 'operator/v_tambah', $data);
    }
    public function cek()
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['standar'] = $this->m_admin->get_standar();
        $this->load->view('operator/cek', $data);
    }

    //request data sub_standar berdasarkan id standar yang di pilih
    function sub_standar()
    {
        $kategori_id = $this->input->post('kat');
        $data = $this->m_admin->get_sub_standar($kategori_id);
        echo json_encode($data);
    }
    //TAMBAH VIEW
    public function tambah_file()
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "C.1";
        $data['title2'] = "Visi, Misi, Tujuan dan Strategi";
        $data['skon'] = $this->db->query('SELECT *FROM sub_arsip WHERE sub_arsip_kategori = 2')->result();
        $data['kon'] = $this->db->query('SELECT *FROM kategori WHERE kategori_id = 2')->row();
        $this->template_op->load('template_op', 'operator/v_tambah', $data);
    }
    public function tambah_file2()
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "C.2";
        $data['title2'] = "Tata Pamong, Tata Kelola dan Kerjasama";
        $data['skon'] = $this->db->query('SELECT *FROM sub_arsip WHERE sub_arsip_kategori = 3')->result();
        $data['kon'] = $this->db->query('SELECT *FROM kategori WHERE kategori_id = 3')->row();
        $this->template_op->load('template_op', 'operator/v_tambah', $data);
    }
    public function tambah_file3()
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "C.3";
        $data['title2'] = "Mahasiswa";
        $data['skon'] = $this->db->query('SELECT *FROM sub_arsip WHERE sub_arsip_kategori = 4')->result();
        $data['kon'] = $this->db->query('SELECT *FROM kategori WHERE kategori_id = 4')->row();
        $this->template_op->load('template_op', 'operator/v_tambah', $data);
    }
    public function tambah_file4()
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "C.4";
        $data['title2'] = "Sumber Daya Manusia";
        $data['skon'] = $this->db->query('SELECT *FROM sub_arsip WHERE sub_arsip_kategori = 5')->result();
        $data['kon'] = $this->db->query('SELECT *FROM kategori WHERE kategori_id = 5')->row();
        $this->template_op->load('template_op', 'operator/v_tambah', $data);
    }
    public function tambah_file5()
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "C.5";
        $data['title2'] = "Keuangan, Sarana, Dan Prasarana";
        $data['skon'] = $this->db->query('SELECT *FROM sub_arsip WHERE sub_arsip_kategori = 6')->result();
        $data['kon'] = $this->db->query('SELECT *FROM kategori WHERE kategori_id = 6')->row();
        $this->template_op->load('template_op', 'operator/v_tambah', $data);
    }
    public function tambah_file6()
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "C.6";
        $data['title2'] = "Pendidikan";
        $data['skon'] = $this->db->query('SELECT *FROM sub_arsip WHERE sub_arsip_kategori = 7')->result();
        $data['kon'] = $this->db->query('SELECT *FROM kategori WHERE kategori_id = 7')->row();
        $this->template_op->load('template_op', 'operator/v_tambah', $data);
    }
    public function tambah_file7()
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "C.7";
        $data['title2'] = "Penelitian";
        $data['skon'] = $this->db->query('SELECT *FROM sub_arsip WHERE sub_arsip_kategori = 8')->result();
        $data['kon'] = $this->db->query('SELECT *FROM kategori WHERE kategori_id = 8')->row();
        $this->template_op->load('template_op', 'operator/v_tambah', $data);
    }
    public function tambah_file8()
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "C.8";
        $data['title2'] = "Pengabdian Kepada Masyarakat";
        $data['skon'] = $this->db->query('SELECT *FROM sub_arsip WHERE sub_arsip_kategori = 9')->result();
        $data['kon'] = $this->db->query('SELECT *FROM kategori WHERE kategori_id = 9')->row();
        $this->template_op->load('template_op', 'operator/v_tambah', $data);
    }
    public function tambah_file9()
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "C.9";
        $data['title2'] = "Luaran dan Capaian Tridharma";
        $data['skon'] = $this->db->query('SELECT *FROM sub_arsip WHERE sub_arsip_kategori = 10')->result();
        $data['kon'] = $this->db->query('SELECT *FROM kategori WHERE kategori_id = 10')->row();
        $this->template_op->load('template_op', 'operator/v_tambah', $data);
    }

    public function proses_tambah_file()
    {
        $keterangan = $this->input->post('keterangan', TRUE);
        $kategori = $this->input->post('kategori', TRUE);
        $id_user = $this->session->userdata("user_id");
        $nama = $this->input->post('nama', TRUE);
        $tgl = $this->input->post('tgl', TRUE);
        $tahuns = $this->input->post('tahuns', TRUE);
        $file = $this->input->post('file', true);
        if ($kategori == 2) {
            $dar = array(
                'arsip_waktu_upload' => $tgl,
                'arsip_nama' => $nama,
                'arsip_user' => $id_user,
                'arsip_kategori' => $kategori,
                'arsip_ts' => $tahuns,
                'arsip_sub_arsip' => $keterangan,
                'arsip_file' => $file,
            );
            $this->db->insert('arsip', $dar);
            redirect('operator/standar1/' . $keterangan . '/?' . 'alert=berhasil');
        } elseif ($kategori == 3) {
            $dar = array(
                'arsip_waktu_upload' => $tgl,
                'arsip_nama' => $nama,
                'arsip_user' => $id_user,
                'arsip_kategori' => $kategori,
                'arsip_ts' => $tahuns,
                'arsip_sub_arsip' => $keterangan,
                'arsip_file' => $file,
            );
            $this->db->insert('arsip', $dar);
            redirect('operator/standar2/' . $keterangan . '/?' . 'alert=berhasil');
        } elseif ($kategori == 4) {
            $dar = array(
                'arsip_waktu_upload' => $tgl,
                'arsip_nama' => $nama,
                'arsip_user' => $id_user,
                'arsip_kategori' => $kategori,
                'arsip_ts' => $tahuns,
                'arsip_sub_arsip' => $keterangan,
                'arsip_file' => $file,
            );
            $this->db->insert('arsip', $dar);
            redirect('operator/standar3/' . $keterangan . '/?' . 'alert=berhasil');
        } elseif ($kategori == 5) {
            $dar = array(
                'arsip_waktu_upload' => $tgl,
                'arsip_nama' => $nama,
                'arsip_user' => $id_user,
                'arsip_kategori' => $kategori,
                'arsip_ts' => $tahuns,
                'arsip_sub_arsip' => $keterangan,
                'arsip_file' => $file,
            );
            $this->db->insert('arsip', $dar);
            redirect('operator/standar4/' . $keterangan . '/?' . 'alert=berhasil');
        } elseif ($kategori == 6) {
            $dar = array(
                'arsip_waktu_upload' => $tgl,
                'arsip_nama' => $nama,
                'arsip_user' => $id_user,
                'arsip_kategori' => $kategori,
                'arsip_ts' => $tahuns,
                'arsip_sub_arsip' => $keterangan,
                'arsip_file' => $file,
            );
            $this->db->insert('arsip', $dar);
            redirect('operator/standar5/' . $keterangan . '/?' . 'alert=berhasil');
        } elseif ($kategori == 7) {
            $dar = array(
                'arsip_waktu_upload' => $tgl,
                'arsip_nama' => $nama,
                'arsip_user' => $id_user,
                'arsip_kategori' => $kategori,
                'arsip_ts' => $tahuns,
                'arsip_sub_arsip' => $keterangan,
                'arsip_file' => $file,
            );
            $this->db->insert('arsip', $dar);
            redirect('operator/standar6/' . $keterangan . '/?' . 'alert=berhasil');
        } elseif ($kategori == 8) {
            $dar = array(
                'arsip_waktu_upload' => $tgl,
                'arsip_nama' => $nama,
                'arsip_user' => $id_user,
                'arsip_kategori' => $kategori,
                'arsip_ts' => $tahuns,
                'arsip_sub_arsip' => $keterangan,
                'arsip_file' => $file,
            );
            $this->db->insert('arsip', $dar);
            redirect('operator/standar7/' . $keterangan . '/?' . 'alert=berhasil');
        } elseif ($kategori == 9) {
            $dar = array(
                'arsip_waktu_upload' => $tgl,
                'arsip_nama' => $nama,
                'arsip_user' => $id_user,
                'arsip_kategori' => $kategori,
                'arsip_ts' => $tahuns,
                'arsip_sub_arsip' => $keterangan,
                'arsip_file' => $file,
            );
            $this->db->insert('arsip', $dar);
            redirect('operator/standar8/' . $keterangan . '/?' . 'alert=berhasil');
        } elseif ($kategori == 10) {
            $dar = array(
                'arsip_waktu_upload' => $tgl,
                'arsip_nama' => $nama,
                'arsip_user' => $id_user,
                'arsip_kategori' => $kategori,
                'arsip_ts' => $tahuns,
                'arsip_sub_arsip' => $keterangan,
                'arsip_file' => $file,
            );
            $this->db->insert('arsip', $dar);
            redirect('operator/standar9/' . $keterangan . '/?' . 'alert=berhasil');
        }
    }

    public function edit($arsip_id)
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "C.1";
        $data['title2'] = "Visi, Misi, Tujuan dan Strategi";
        $data['skon'] = $this->db->query('SELECT *FROM sub_arsip WHERE sub_arsip_kategori = 2')->result();
        $data['me'] = $this->m_admin->masuk_edit($arsip_id);
        $this->template_op->load('template_op', 'operator/v_edit', $data);
    }
    public function edit2($arsip_id)
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "C.2";
        $data['title2'] = "Tata Pamong, Tata Kelola dan Kerjasama";
        $data['skon'] = $this->db->query('SELECT *FROM sub_arsip WHERE sub_arsip_kategori = 3')->result();
        $data['me'] = $this->m_admin->masuk_edit($arsip_id);
        $this->template_op->load('template_op', 'operator/v_edit', $data);
    }
    public function edit3($arsip_id)
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "C.3";
        $data['title2'] = "Mahasiswa";
        $data['skon'] = $this->db->query('SELECT *FROM sub_arsip WHERE sub_arsip_kategori = 4')->result();
        $data['me'] = $this->m_admin->masuk_edit($arsip_id);
        $this->template_op->load('template_op', 'operator/v_edit', $data);
    }
    public function edit4($arsip_id)
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "C.4";
        $data['title2'] = "Sumber Daya Manusia";
        $data['skon'] = $this->db->query('SELECT *FROM sub_arsip WHERE sub_arsip_kategori = 5')->result();
        $data['me'] = $this->m_admin->masuk_edit($arsip_id);
        $this->template_op->load('template_op', 'operator/v_edit', $data);
    }
    public function edit5($arsip_id)
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "C.5";
        $data['title2'] = "Keuangan, Sarana, Dan Prasarana";
        $data['skon'] = $this->db->query('SELECT *FROM sub_arsip WHERE sub_arsip_kategori = 6')->result();
        $data['me'] = $this->m_admin->masuk_edit($arsip_id);
        $this->template_op->load('template_op', 'operator/v_edit', $data);
    }
    public function edit6($arsip_id)
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "C.6";
        $data['title2'] = "Pendidikan";
        $data['skon'] = $this->db->query('SELECT *FROM sub_arsip WHERE sub_arsip_kategori = 7')->result();
        $data['me'] = $this->m_admin->masuk_edit($arsip_id);
        $this->template_op->load('template_op', 'operator/v_edit', $data);
    }
    public function edit7($arsip_id)
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "C.7";
        $data['title2'] = "Penelitian";
        $data['skon'] = $this->db->query('SELECT *FROM sub_arsip WHERE sub_arsip_kategori = 8')->result();
        $data['me'] = $this->m_admin->masuk_edit($arsip_id);
        $this->template_op->load('template_op', 'operator/v_edit', $data);
    }
    public function edit8($arsip_id)
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "C.8";
        $data['title2'] = "Pengabdian Kepada Masyarakat";
        $data['skon'] = $this->db->query('SELECT *FROM sub_arsip WHERE sub_arsip_kategori = 9')->result();
        $data['me'] = $this->m_admin->masuk_edit($arsip_id);
        $this->template_op->load('template_op', 'operator/v_edit', $data);
    }
    public function edit9($arsip_id)
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "C.9";
        $data['title2'] = "Luaran dan Capaian Tridharma";
        $data['skon'] = $this->db->query('SELECT *FROM sub_arsip WHERE sub_arsip_kategori = 10')->result();
        $data['me'] = $this->m_admin->masuk_edit($arsip_id);
        $this->template_op->load('template_op', 'operator/v_edit', $data);
    }
    public function proses_edit($arsip_id)
    {
        $user = $this->session->userdata("user_id");
        $keterangan = $this->input->post('keterangan', true);
        $kategori = $this->input->post('kategori', TRUE);
        $nama = $this->input->post('nama', TRUE);
        $tgl = $this->input->post('tgl', TRUE);
        $tahuns = $this->input->post('tahuns', TRUE);
        $file = $this->input->post('file', true);
        //Standar 1
        if ($kategori == 2) {
            $dar = array(
                'arsip_waktu_upload' => $tgl,
                'arsip_nama' => $nama,
                'arsip_user' => $user,
                'arsip_kategori' => $kategori,
                'arsip_ts' => $tahuns,
                'arsip_sub_arsip' => $keterangan,
                'arsip_file' => $file,
            );
            $this->db->where('arsip_id', $arsip_id);
            $this->db->update('arsip', $dar);
            redirect('operator/standar1/' . $keterangan . '/?' . 'alert=berhasil');


            //Standar 2
        } elseif ($kategori == 3) {
            $dar = array(
                'arsip_waktu_upload' => $tgl,
                'arsip_nama' => $nama,
                'arsip_user' => $user,
                'arsip_kategori' => $kategori,
                'arsip_ts' => $tahuns,
                'arsip_sub_arsip' => $keterangan,
                'arsip_file' => $file,
            );
            $this->db->where('arsip_id', $arsip_id);
            $this->db->update('arsip', $dar);
            redirect('operator/standar2/' . $keterangan . '/?' . 'alert=berhasil');
            //Standar 3
        } elseif ($kategori == 4) {
            $dar = array(
                'arsip_waktu_upload' => $tgl,
                'arsip_nama' => $nama,
                'arsip_user' => $user,
                'arsip_kategori' => $kategori,
                'arsip_ts' => $tahuns,
                'arsip_sub_arsip' => $keterangan,
                'arsip_file' => $file,
            );
            $this->db->where('arsip_id', $arsip_id);
            $this->db->update('arsip', $dar);
            redirect('operator/standar3/' . $keterangan . '/?' . 'alert=berhasil');

            //Standar 4
        } elseif ($kategori == 5) {
            $dar = array(
                'arsip_waktu_upload' => $tgl,
                'arsip_nama' => $nama,
                'arsip_user' => $user,
                'arsip_kategori' => $kategori,
                'arsip_ts' => $tahuns,
                'arsip_sub_arsip' => $keterangan,
                'arsip_file' => $file,
            );
            $this->db->where('arsip_id', $arsip_id);
            $this->db->update('arsip', $dar);
            redirect('operator/standar4/' . $keterangan . '/?' . 'alert=berhasil');

            //Standar 5
        } elseif ($kategori == 6) {
            $dar = array(
                'arsip_waktu_upload' => $tgl,
                'arsip_nama' => $nama,
                'arsip_user' => $user,
                'arsip_kategori' => $kategori,
                'arsip_ts' => $tahuns,
                'arsip_sub_arsip' => $keterangan,
                'arsip_file' => $file,
            );
            $this->db->where('arsip_id', $arsip_id);
            $this->db->update('arsip', $dar);
            redirect('operator/standar5/' . $keterangan . '/?' . 'alert=berhasil');
        } elseif ($kategori == 7) {
            $dar = array(
                'arsip_waktu_upload' => $tgl,
                'arsip_nama' => $nama,
                'arsip_user' => $user,
                'arsip_kategori' => $kategori,
                'arsip_ts' => $tahuns,
                'arsip_sub_arsip' => $keterangan,
                'arsip_file' => $file,
            );
            $this->db->where('arsip_id', $arsip_id);
            $this->db->update('arsip', $dar);
            redirect('operator/standar6/' . $keterangan . '/?' . 'alert=berhasil');
        } elseif ($kategori == 8) {
            $dar = array(
                'arsip_waktu_upload' => $tgl,
                'arsip_nama' => $nama,
                'arsip_user' => $user,
                'arsip_kategori' => $kategori,
                'arsip_ts' => $tahuns,
                'arsip_sub_arsip' => $keterangan,
                'arsip_file' => $file,
            );
            $this->db->where('arsip_id', $arsip_id);
            $this->db->update('arsip', $dar);
            redirect('operator/standar7/' . $keterangan . '/?' . 'alert=berhasil');
        } elseif ($kategori == 9) {
            $dar = array(
                'arsip_waktu_upload' => $tgl,
                'arsip_nama' => $nama,
                'arsip_user' => $user,
                'arsip_kategori' => $kategori,
                'arsip_ts' => $tahuns,
                'arsip_sub_arsip' => $keterangan,
                'arsip_file' => $file,
            );
            $this->db->where('arsip_id', $arsip_id);
            $this->db->update('arsip', $dar);
            redirect('operator/standar8/' . $keterangan . '/?' . 'alert=berhasil');
        } elseif ($kategori == 10) {
            $dar = array(
                'arsip_waktu_upload' => $tgl,
                'arsip_nama' => $nama,
                'arsip_user' => $user,
                'arsip_kategori' => $kategori,
                'arsip_ts' => $tahuns,
                'arsip_sub_arsip' => $keterangan,
                'arsip_file' => $file,
            );
            $this->db->where('arsip_id', $arsip_id);
            $this->db->update('arsip', $dar);
            redirect('operator/standar9/' . $keterangan . '/?' . 'alert=berhasil');
        }
    }
    function pass()
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $this->template_op->load('template_op', 'operator/ganti_password', $data);
    }

    function update()
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1);
        $id_user = $this->session->userdata("user_id");

        $user_password = $this->input->post('password');

        $data1 = array(
            'user_password' => md5($user_password)
        );

        $user_id = array(
            'user_id' => $id_user
        );

        $this->m_admin->update_data($user_id, $data1, 'user');
        redirect('operator/pass/?' . 'alert=sukses');
    }

    public function hapus_standar($arsip_id)
    {
        $sub = $this->db->query('SELECT * FROM arsip where arsip_id =' . $arsip_id);
        $where = array('arsip_id' => $arsip_id);
        $this->m_admin->hapus($where, 'arsip');
        redirect('operator/?alert=hapus');
    }

    public function edit_kondisi($arsip_id)
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "Edit Kondisi Eksternal";
        $data['me'] = $this->m_admin->masuk_edit_kon($arsip_id);
        $this->template_op->load('template_op', 'operator/edit_kondisi', $data);
    }
    function proses_edit_file_kondisi($arsip_id)
    {
        $kategori = $this->input->post('kategori', TRUE);
        $id_user = $this->session->userdata("user_id");
        $nama = $this->input->post('nama', TRUE);
        $tgl = $this->input->post('tgl', TRUE);
        $tahuns = $this->input->post('tahuns', TRUE);
        $file = $this->input->post('file', true);

        $dar = array(
            'arsip_waktu_upload' => $tgl,
            'arsip_nama' => $nama,
            'arsip_user' => $id_user,
            'arsip_kategori' => $kategori,
            'arsip_ts' => $tahuns,
            'arsip_file' => $file,
        );
        $this->db->where('arsip_id', $arsip_id);
        $this->db->update('arsip', $dar);
        redirect('operator/kondisi_eksternal/?' . 'alert=update');
    }
    public function kondisi_eksternal()
    {
        $id_user = $this->session->userdata("user_id");
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "Kondisi Eksternal";
        $data['masuk'] = $this->m_admin->koneks_op($id_user);
        $this->template_op->load('template_op', 'operator/kon_eks', $data);
    }
    function tambah_file_kondisi()
    {
        $where1 = array('user_id' => $this->session->userdata("user_id"));
        $data['user'] = $this->m_admin->cek_login('user', $where1)->result();
        $data['title1'] = "Tambah Kondisi Eksternal";
        $data['kon'] = $this->db->query('SELECT *FROM kategori WHERE kategori_id = 11')->row();
        $this->template_op->load('template_op', 'operator/v_tambah_kon', $data);
    }
    function proses_tambah_file_kondisi()
    {
        $kategori = $this->input->post('kategori', TRUE);
        $id_user = $this->session->userdata("user_id");
        $nama = $this->input->post('nama', TRUE);
        $tgl = $this->input->post('tgl', TRUE);
        $tahuns = $this->input->post('tahuns', TRUE);
        $file = $this->input->post('file', true);

        $dar = array(
            'arsip_waktu_upload' => $tgl,
            'arsip_nama' => $nama,
            'arsip_user' => $id_user,
            'arsip_kategori' => $kategori,
            'arsip_ts' => $tahuns,
            'arsip_file' => $file,
        );
        $this->db->insert('arsip', $dar);
        redirect('operator/kondisi_eksternal/?' . 'alert=berhasil');
    }
}
