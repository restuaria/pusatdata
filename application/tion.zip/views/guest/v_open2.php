<div class="pagetitle">
    <h1>Dashboard</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo base_url('guest') ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?php echo base_url() . 'guest/open/' . $kategori->kategori_id ?>"><?= $kategori->kategori_nama ?></a></li>
            <li class="breadcrumb-item active"><?= $naskah->naskah_nama ?></li>
        </ol>
    </nav>
</div><!-- End Page Title -->

<section class="section dashboard">
    <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
            <div class="row">
                <table id="example">
                    <thead>
                        <tr>
                            <th width="1%" style="text-align:center">NO</th>
                            <th style="text-align:center">Arsip Nama</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($file as $k) {
                        ?>
                            <tr>
                                <td style="text-align:center"><?php echo $no++; ?></td>
                                <td style="text-align:center;color:black;">
                                    <p>
                                        <a class="text-black" href="<?php echo base_url("guest/viewpdf/$k->arsip_id") ?>">
                                            <img src="<?php echo base_url("assets/img/file.png") ?>" alt="" style="height: 40px;">
                                            <?= $k->arsip_nama ?>
                                        </a>
                                    </p>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                    </tbody>
                </table>

            </div>
        </div><!-- End Left side columns -->
    </div>
</section>