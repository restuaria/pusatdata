<div class="pagetitle">
    <h1>Dashboard</h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo base_url('guest') ?>">Dashboard</a></li>
            <li class="breadcrumb-item active"><a href="<?php echo base_url() . 'guest/open/' . $kategori->kategori_id ?>"><?= $kategori->kategori_nama ?></a></li>
        </ol>
    </nav>
</div><!-- End Page Title -->

<section class="section dashboard">
    <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-12">
            <div class="row">
                <?php
                foreach ($naskah as $k) { ?>
                    <div class="col-xxl-3 col-md-3">
                        <a href="<?php echo base_url("guest/opentoopen/$kategori->kategori_id/$k->naskah_id") ?>">
                            <div class="card info-card" style="height:150px;">
                                <div class="card-body">
                                    <div class="d-flex align-items-center">
                                        <div class="d-flex align-items-center justify-content-center">
                                            <img src="<?php echo base_url("assets/img/folder.png") ?>" alt="" style="height: 60px;">
                                        </div>
                                        <div class="ps-3">
                                            <h5 class="card-title"><?= $k->naskah_nama ?></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>

                    </div>
                <?php }
                ?>
            </div>
        </div><!-- End Left side columns -->
    </div>
</section>