<div class="pagetitle">
    <h1><?= $title1 ?> <?= $title2 ?></h1>
    <nav>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= base_url('guest') ?>">Home</a></li>
            <li class="breadcrumb-item "><?= $title1 ?> <?= $title2 ?></li>
            <li class="breadcrumb-item active"><?= $title3->sub_arsip_nama ?></li>
        </ol>
    </nav>
</div><!-- End Page Title -->

<section class="section">
    <div class="row">
        <div class="col-lg-12">

            <div class="card">

                <div class="card-body">
                    <h5 class="card-title">Data <?= $title1 ?> <?= $title2 ?></h5>
                    <div class="btn-group mb-1">
                        <form action="<?php echo base_url() . 'guest/standar3/' . $ts->sub_arsip_id; ?>" method="post">
                            <label for="ts">Pilih Tahun Semester : <br></label>
                            <select name="pilihts" class="form-control">
                                <option value="">Semua TS</option>
                                <option value="1">TS</option>
                                <option value="2">TS-1</option>
                                <option value="3">TS-2</option>
                            </select>
                            <br>
                            <input type="submit" class="btn btn-sm btn-danger" value="Submit">
                        </form>
                    </div>

                    <!-- Table with stripped rows -->
                    <table class="table datatable">
                        <thead>
                            <tr>
                                <th style="text-align:center" width="1%">No</th>
                                <th style="text-align:center">Tanggal</th>
                                <th style="text-align:center">Nama File</th>
                                <th style="text-align:center">Lokasi</th>
                                <th style="text-align:center">User Upload</th>
                                <th style="text-align:center">TS</th>
                                <th width="15%" style="text-align:center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            foreach ($masuk as $p) {
                            ?>
                                <tr>
                                    <td style="text-align:center"><?= $no++; ?></td>
                                    <td style="text-align:center"><?= $p->arsip_waktu_upload ?></td>
                                    <td style="text-align:center"><?= $p->arsip_nama ?></td>
                                    <td style="text-align:center"><?= $p->sub_arsip_nama ?></td>
                                    <td style="text-align:center"><?= $p->user_nama ?></td>
                                    <td style="text-align:center"><?= $p->arsip_ts ?></td>
                                    <td>
                                        <!-- modal hapus -->
                                        <div class="btn-group">
                                            <a target="_blank" title="view" class="btn btn-primary" href="<?php echo base_url() . 'guest/viewpdf/' . $p->arsip_id ?>"><i class="bi bi-search"></i></a>
                                        </div>
                                    </td>
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                    <!-- End Table with stripped rows -->

                </div>
            </div>

        </div>
    </div>
</section>